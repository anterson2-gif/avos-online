/**
 * Avós Online - Assistive Engine (Gerontecnologia)
 * Recursos: Web Speech API (TTS pt-BR pausado), Web Audio API (Sons de clique), Vibração háptica, Escala de Fontes
 */

class AvosAssistiveEngine {
  constructor() {
    this.voiceEnabled = localStorage.getItem('avos_voice_enabled') !== 'false';
    this.fontSizeLevel = parseInt(localStorage.getItem('avos_font_size') || '0', 10);
    this.audioCtx = null;
    this.sharedAudio = typeof Audio !== 'undefined' ? new Audio() : null;
    if (this.sharedAudio) {
      this.sharedAudio.preload = 'auto';
      this.sharedAudio.playsInline = true;
    }
    this.audioUnlocked = false;
    this.synth = window.speechSynthesis;
    this.ptVoice = null;

    this.initAudioContext();
    this.initVoices();
    this.applyFontSize();
    this.bindEvents();
  }

  // Inicializa o contexto de áudio sintetizado para não depender de arquivos externos
  initAudioContext() {
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) {
        this.audioCtx = new AudioContext();
      }
    } catch (e) {
      console.warn('AudioContext não disponível:', e);
    }
  }

  ensureAudioUnlocked() {
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    // Desbloqueia o elemento de áudio compartilhado para iPhone / iOS Safari (permite troca de cenas automáticas)
    if (!this.audioUnlocked && this.sharedAudio) {
      this.audioUnlocked = true;
      try {
        // Silêncio WAV curto em base64 apenas para destravar o canal de mídia do iOS no 1º toque
        this.sharedAudio.src = 'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA';
        const p = this.sharedAudio.play();
        if (p !== undefined) {
          p.then(() => {
            this.sharedAudio.pause();
            this.sharedAudio.currentTime = 0;
          }).catch(() => {});
        }
      } catch (e) {}
    }
  }

  // Som suave de confirmação de toque (acorde duplo harmônico 520Hz + 660Hz)
  playConfirmSound() {
    this.ensureAudioUnlocked();
    if (!this.audioCtx) return;

    try {
      const now = this.audioCtx.currentTime;
      const osc1 = this.audioCtx.createOscillator();
      const osc2 = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();

      osc1.type = 'sine';
      osc2.type = 'triangle';

      osc1.frequency.setValueAtTime(523.25, now); // Dó5
      osc1.frequency.exponentialRampToValueAtTime(659.25, now + 0.12); // Mi5

      osc2.frequency.setValueAtTime(329.63, now); // Mi4
      osc2.frequency.exponentialRampToValueAtTime(440.00, now + 0.12); // Lá4

      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(this.audioCtx.destination);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.25);
      osc2.stop(now + 0.25);
    } catch (e) {
      // Falha silenciosa
    }
  }

  // Som de alerta / perigo (usado em avisos de golpes)
  playAlertSound() {
    this.ensureAudioUnlocked();
    if (!this.audioCtx) return;

    try {
      const now = this.audioCtx.currentTime;
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(400, now);
      osc.frequency.setValueAtTime(250, now + 0.15);

      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

      osc.connect(gain);
      gain.connect(this.audioCtx.destination);

      osc.start(now);
      osc.stop(now + 0.35);
    } catch (e) {}
  }

  // Som de sucesso (vitória em quiz / transferência concluída)
  playSuccessSound() {
    this.ensureAudioUnlocked();
    if (!this.audioCtx) return;

    try {
      const now = this.audioCtx.currentTime;
      [440, 554.37, 659.25, 880].forEach((freq, idx) => {
        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + (idx * 0.08));
        gain.gain.setValueAtTime(0.18, now + (idx * 0.08));
        gain.gain.exponentialRampToValueAtTime(0.001, now + (idx * 0.08) + 0.2);
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        osc.start(now + (idx * 0.08));
        osc.stop(now + (idx * 0.08) + 0.2);
      });
    } catch (e) {}
  }

  // Vibração suave no celular (40 milissegundos)
  vibrate(duration = 40) {
    if (window.navigator && window.navigator.vibrate) {
      try {
        window.navigator.vibrate(duration);
      } catch (e) {}
    }
  }

  // Inicialização de vozes do navegador pt-BR com priorização estrita de vozes naturais
  initVoices() {
    if (!this.synth) return;

    const findVoice = () => {
      const voices = this.synth.getVoices();
      if (!voices || voices.length === 0) return;

      const ptVoices = voices.filter(v => v.lang.startsWith('pt-BR') || v.lang.startsWith('pt'));
      if (ptVoices.length === 0) return;

      const scoreVoice = (v) => {
        let score = 0;
        const name = (v.name || '').toLowerCase();
        const lang = (v.lang || '').toLowerCase();

        if (lang.includes('br')) score += 100;

        // Prioridade para vozes neurais e online naturais
        if (name.includes('natural')) score += 500;
        if (name.includes('neural')) score += 400;
        if (name.includes('online')) score += 300;

        // Vozes humanas de qualidade reconhecida (Android, Windows e iOS/iPhone)
        if (name.includes('francisca')) score += 350;
        if (name.includes('thalita')) score += 250;
        if (name.includes('antonio')) score += 200;
        if (name.includes('google')) score += 250;
        if (name.includes('luciana')) score += 280;
        if (name.includes('siri')) score += 350;
        if (name.includes('premium') || name.includes('enhanced')) score += 300;

        // Penaliza a voz robótica legada do Windows Desktop
        if (name.includes('desktop')) score -= 300;
        if (v.localService === true && !name.includes('google')) score -= 100;

        return score;
      };

      ptVoices.sort((a, b) => scoreVoice(b) - scoreVoice(a));
      this.ptVoice = ptVoices[0];
    };

    findVoice();
    if (this.synth.onvoiceschanged !== undefined) {
      this.synth.onvoiceschanged = findVoice;
    }
  }

  // Narração por voz: reproduz áudio neural de estúdio com fallback para síntese
  speak(text, onEnd = null) {
    if (!text) {
      if (typeof onEnd === 'function') onEnd();
      return;
    }

    if (!this.voiceEnabled) {
      if (typeof onEnd === 'function') {
        const tempoLeituraMs = Math.max(3500, Math.min(7500, text.length * 65));
        this.fallbackTimer = setTimeout(onEnd, tempoLeituraMs);
      }
      return;
    }

    this.stopVoice();

    let finalizado = false;
    const finalizarUmaVez = () => {
      if (!finalizado) {
        finalizado = true;
        this.currentAudio = null;
        this.currentUtterance = null;
        if (this.safetyTimer) {
          clearTimeout(this.safetyTimer);
          this.safetyTimer = null;
        }
        if (typeof onEnd === 'function') {
          onEnd();
        }
      }
    };

    // 1. Tenta reproduzir o áudio neural de alta fidelidade via endpoint /api/tts reutilizando elemento desbloqueado no iOS
    try {
      const audioUrl = `/api/tts?text=${encodeURIComponent(text.trim())}`;
      const audio = this.sharedAudio || new Audio();
      this.audioUnlocked = true;
      audio.onended = null;
      audio.onerror = null;
      audio.src = audioUrl;
      this.currentAudio = audio;

      audio.onended = () => {
        finalizarUmaVez();
      };

      audio.onerror = () => {
        // Fallback para Web Speech API se houver falha de rede ou mídia
        this.speakWebSpeech(text, finalizarUmaVez);
      };

      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise.catch((err) => {
          console.warn('Reprodução de áudio direta prevenida, usando sintetizador:', err);
          this.speakWebSpeech(text, finalizarUmaVez);
        });
      }

      // Timer de segurança
      const tempoMaximoMs = Math.max(6000, text.length * 150);
      this.safetyTimer = setTimeout(finalizarUmaVez, tempoMaximoMs);

    } catch (e) {
      this.speakWebSpeech(text, finalizarUmaVez);
    }
  }

  // Fallback para Web Speech API com voz otimizada
  speakWebSpeech(text, onEnd) {
    if (!this.synth) {
      if (typeof onEnd === 'function') onEnd();
      return;
    }

    try {
      if (this.synth.paused) {
        this.synth.resume();
      }

      const utterance = new SpeechSynthesisUtterance(text);
      if (this.ptVoice) {
        utterance.voice = this.ptVoice;
      }
      utterance.lang = 'pt-BR';
      utterance.rate = 0.92;
      utterance.pitch = 1.0;

      this.currentUtterance = utterance;

      utterance.onend = () => {
        if (typeof onEnd === 'function') onEnd();
      };

      utterance.onerror = () => {
        if (typeof onEnd === 'function') onEnd();
      };

      this.synth.speak(utterance);
    } catch (e) {
      if (typeof onEnd === 'function') onEnd();
    }
  }

  stopVoice() {
    if (this.fallbackTimer) {
      clearTimeout(this.fallbackTimer);
      this.fallbackTimer = null;
    }
    if (this.safetyTimer) {
      clearTimeout(this.safetyTimer);
      this.safetyTimer = null;
    }
    if (this.currentAudio) {
      try {
        this.currentAudio.pause();
        this.currentAudio.currentTime = 0;
      } catch (e) {}
      this.currentAudio = null;
    }
    if (this.synth) {
      try {
        this.synth.cancel();
      } catch (e) {}
    }
    this.currentUtterance = null;
  }

  // Alternador de Voz (Ligar/Desligar)
  toggleVoice() {
    this.voiceEnabled = !this.voiceEnabled;
    localStorage.setItem('avos_voice_enabled', this.voiceEnabled);
    this.updateVoiceButtonUI();

    if (this.voiceEnabled) {
      this.playConfirmSound();
      this.speak("Voz ativada! Eu vou te acompanhar em cada passo.");
    } else {
      this.stopVoice();
    }
  }

  updateVoiceButtonUI() {
    const btn = document.getElementById('btnToggleVoice');
    if (btn) {
      if (this.voiceEnabled) {
        btn.innerHTML = '🔊 Voz: LIGADA';
        btn.classList.add('active');
        btn.setAttribute('aria-label', 'Voz ligada. Toque para desligar');
      } else {
        btn.innerHTML = '🔇 Voz: DESLIGADA';
        btn.classList.remove('active');
        btn.setAttribute('aria-label', 'Voz desligada. Toque para ligar');
      }
    }
  }

  // Controle de tamanho de fontes (0: Normal, 1: Grande, 2: Extra Grande)
  cycleFontSize() {
    this.fontSizeLevel = (this.fontSizeLevel + 1) % 3;
    localStorage.setItem('avos_font_size', this.fontSizeLevel);
    this.applyFontSize();
    this.playConfirmSound();

    const desc = ['Tamanho de letra normal', 'Tamanho de letra grande', 'Tamanho de letra gigante'];
    this.speak(desc[this.fontSizeLevel]);
  }

  applyFontSize() {
    document.body.classList.remove('font-large', 'font-xlarge');
    if (this.fontSizeLevel === 1) {
      document.body.classList.add('font-large');
    } else if (this.fontSizeLevel === 2) {
      document.body.classList.add('font-xlarge');
    }
  }

  // Detecta se o usuário está em iPhone / iPad (iOS)
  isIOS() {
    const ua = window.navigator.userAgent || '';
    const isIPhoneIPad = /iPad|iPhone|iPod/.test(ua);
    const isMacTouch = ua.includes('Mac') && 'ontouchend' in document;
    return isIPhoneIPad || isMacTouch;
  }

  // Detecta se já está rodando instalado na tela inicial (Standalone)
  isStandalone() {
    return (
      window.matchMedia('(display-mode: standalone)').matches ||
      window.navigator.standalone === true
    );
  }

  // Aciona instalação inteligente para Android (1 clique) ou guia visual para iPhone/iOS
  async instalarAplicativo() {
    this.playConfirmSound();
    this.vibrate(50);

    // Se o navegador Android já capturou o prompt nativo de instalação
    if (this.deferredPrompt) {
      try {
        this.deferredPrompt.prompt();
        const { outcome } = await this.deferredPrompt.userChoice;
        if (outcome === 'accepted') {
          this.speak('Instalando o aplicativo Avós Online na tela inicial do seu celular!');
          this.deferredPrompt = null;
          const banner = document.getElementById('bannerInstalarApp');
          if (banner) banner.style.display = 'none';
        }
        return;
      } catch (e) {
        console.warn('Erro ao abrir prompt nativo:', e);
      }
    }

    // Abre o modal de instruções específico para iPhone (iOS) ou Android
    const modal = document.getElementById('modalInstalacaoApp');
    const boxIOS = document.getElementById('boxInstrucaoIOS');
    const boxAndroid = document.getElementById('boxInstrucaoAndroid');

    if (modal) {
      modal.style.display = 'flex';
      if (this.isIOS()) {
        if (boxIOS) boxIOS.style.display = 'block';
        if (boxAndroid) boxAndroid.style.display = 'none';
        this.speak(
          'Para salvar no seu iPhone: toque no botão de Compartilhar do Safari, depois escolha Adicionar à Tela de Início e confirme em Adicionar!'
        );
      } else {
        if (boxIOS) boxIOS.style.display = 'none';
        if (boxAndroid) boxAndroid.style.display = 'block';
        this.speak(
          'Para instalar no seu celular: toque nos três pontinhos no canto do navegador e escolha Instalar aplicativo ou Adicionar à tela inicial!'
        );
      }
    }
  }

  fecharModalInstalacao() {
    this.playConfirmSound();
    const modal = document.getElementById('modalInstalacaoApp');
    if (modal) {
      modal.style.display = 'none';
    }
  }

  // Vincula eventos automáticos aos botões com feedback duplo
  bindEvents() {
    this.deferredPrompt = null;

    // Captura o evento nativo de instalação PWA no Android / Chrome
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      this.deferredPrompt = e;
      const banner = document.getElementById('bannerInstalarApp');
      if (banner && !this.isStandalone()) {
        banner.style.display = 'flex';
      }
    });

    window.addEventListener('appinstalled', () => {
      this.deferredPrompt = null;
      const banner = document.getElementById('bannerInstalarApp');
      if (banner) banner.style.display = 'none';
    });

    document.addEventListener('DOMContentLoaded', () => {
      this.updateVoiceButtonUI();

      // Oculta o banner de instalação se o app já estiver instalado na tela inicial
      const banner = document.getElementById('bannerInstalarApp');
      const subTextoBanner = document.getElementById('subTextoInstalarApp');
      if (banner) {
        if (this.isStandalone()) {
          banner.style.display = 'none';
        } else if (this.isIOS() && subTextoBanner) {
          subTextoBanner.textContent = 'Compatível com seu iPhone (Safari) — Veja como adicionar em 2 toques';
        }
      }

      // Desbloqueia AudioContext no primeiro toque (essencial para iPhone/iOS)
      document.body.addEventListener('touchstart', () => this.ensureAudioUnlocked(), { once: true });

      // Botão de alternar voz
      const btnVoice = document.getElementById('btnToggleVoice');
      if (btnVoice) {
        btnVoice.addEventListener('click', () => this.toggleVoice());
      }

      // Botão de tamanho da letra
      const btnFont = document.getElementById('btnFontSize');
      if (btnFont) {
        btnFont.addEventListener('click', () => this.cycleFontSize());
      }

      // Todos os botões e links assistivos
      const interactiveElements = document.querySelectorAll('.btn-super, .btn-action-lg, .btn-safe-exit, [data-speak], [data-sound]');

      interactiveElements.forEach((el) => {
        el.addEventListener('click', (e) => {
          this.vibrate(45);
          this.playConfirmSound();

          const speakText = el.getAttribute('data-speak');
          if (speakText) {
            this.speak(speakText);
          }
        });
      });

      // Narração inicial automática da tela, se configurada no elemento raiz
      const autoNarrate = document.querySelector('[data-auto-narrate]');
      if (autoNarrate) {
        setTimeout(() => {
          this.speak(autoNarrate.getAttribute('data-auto-narrate'));
        }, 600);
      }
    });
  }
}

// Instância global disponível para todas as páginas
window.AvosAssistive = new AvosAssistiveEngine();
