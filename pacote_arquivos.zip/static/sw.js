const CACHE_NAME = 'avos-online-v4';
const CORE_ASSETS = [
  '/',
  '/internet',
  '/whatsapp',
  '/banco',
  '/medisafe',
  '/telefone',
  '/maps',
  '/static/css/app.css',
  '/static/js/app.js',
  '/static/manifest.json',
  '/static/icons/icon-192.png',
  '/static/icons/icon-512.png'
];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then(async (cache) => {
      // Faz o pré-cache individualmente para que eventual falha em 1 item não bloqueie os demais
      await Promise.allSettled(
        CORE_ASSETS.map((url) =>
          fetch(url, { cache: 'reload' }).then((res) => {
            if (res && res.ok) {
              return cache.put(url, res);
            }
          })
        )
      );
    })
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;

  // Ignora métodos que não sejam GET (ex: POST /api/banco/pix)
  if (req.method !== 'GET') {
    return;
  }

  const url = new URL(req.url);

  // Ignora chamadas de healthcheck para que sempre acordem o servidor real
  if (url.pathname === '/health') {
    return;
  }

  // Para áudios TTS (/api/tts) e imagens/áudios estáticos: Cache-First para resposta imediata
  if (url.pathname.startsWith('/api/tts') || url.pathname.startsWith('/static/')) {
    event.respondWith(
      caches.open(CACHE_NAME).then(async (cache) => {
        const cached = await cache.match(req);
        if (cached) {
          // Atualiza arquivos CSS/JS em segundo plano sem travar a abertura
          if (url.pathname.endsWith('.css') || url.pathname.endsWith('.js') || url.pathname.endsWith('.json')) {
            fetch(req).then((netRes) => {
              if (netRes && netRes.ok) cache.put(req, netRes.clone());
            }).catch(() => {});
          }
          return cached;
        }
        try {
          const netRes = await fetch(req);
          if (netRes && netRes.ok) {
            cache.put(req, netRes.clone());
          }
          return netRes;
        } catch (err) {
          return new Response('', { status: 408 });
        }
      })
    );
    return;
  }

  // Para as páginas do aplicativo (/, /internet, /whatsapp, /banco, etc.):
  // Estratégia Stale-While-Revalidate (Abertura Instantânea < 50ms a partir do cache enquanto acorda o servidor em 2º plano)
  if (req.mode === 'navigate' || req.headers.get('accept')?.includes('text/html')) {
    event.respondWith(
      caches.open(CACHE_NAME).then(async (cache) => {
        const cachedPage = await cache.match(url.pathname) || await cache.match(req);

        const networkFetch = fetch(req)
          .then((netRes) => {
            if (netRes && netRes.ok) {
              cache.put(url.pathname, netRes.clone());
            }
            return netRes;
          })
          .catch(() => null);

        // Se já temos a tela no cache do celular, abre IMEDIATAMENTE sem tela preta e atualiza em segundo plano!
        if (cachedPage) {
          event.waitUntil(networkFetch);
          return cachedPage;
        }

        // Caso seja o 1º acesso sem cache, busca da rede ou usa a tela inicial em cache como fallback
        const netRes = await networkFetch;
        if (netRes) return netRes;

        const fallbackHome = await cache.match('/');
        return fallbackHome || new Response(
          '<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Avós Online</title></head><body style="background:#1E3A8A;color:#FFF;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center;padding:20px;"><div><div style="font-size:4rem;">👵👴</div><h1 style="color:#FACC15;">Abrindo o Avós Online...</h1><p style="font-size:1.2rem;">Só um instante, preparando os botões grandes para você!</p><script>setTimeout(()=>location.reload(),2500);</script></div></body></html>',
          { headers: { 'Content-Type': 'text/html; charset=utf-8' } }
        );
      })
    );
  }
});
